import asyncio
import websockets

# Function to handle incoming messages from clients
async def handle_message(websocket, path):
    async for message in websocket:
        print("Message from client:", message)
        # Echo the message back to the client
        await websocket.send(message)

# Start the WebSocket server
start_server = websockets.serve(handle_message, 'localhost', 5002)

# Run the server indefinitely
asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
