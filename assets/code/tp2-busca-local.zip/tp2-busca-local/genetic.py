import random

class Individual:
    def __init__(self, width, height, start, end, genotype=None):
        self.width = width
        self.height = height
        self.start = start
        self.end = end

        # Generate a random quadrant map
        if(genotype is not None):
            self.genotype = genotype
        else:
            self.gen_genotype()

    def gen_genotype(self):
        # 1. Representação dos indivíduos: Escreva seu código aqui
        pass

    def get_phenotype(self):
        phenotype = []
        # 1. Representação dos indivíduos: Escreva seu código aqui

        return phenotype

    def fitness(self):
        # 2. Função de adaptação: Escreva seu código aqui
        return 0.0
    
class GeneticAlgorithm:
    def __init__(self, population_size, generations, mutation_rate, width, height, start, end):
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.width = width
        self.height = height
        self.start = start
        self.end = end
        
        self.current_generation = 0
        self.initialize_population()

    def initialize_population(self):
        self.population = []
        # 3. Inicialização da população: Escreva seu código aqui
        
    def selection(self, fitness_scores):
        # 4. Seleção: Escreva seu código aqui
        pass
    
    def crossover(self, parent1, parent2):
        # 5. Cruzamento: Escreva seu código aqui
        pass

    def mutate(self, individual):
        # 6. Mutação: Escreva seu código aqui
        pass
        
    def evolve(self):
        if self.current_generation >= self.generations:
            return (None, None)
        
        # 7. Evolução: Escreva seu código aqui
        return (None, None)