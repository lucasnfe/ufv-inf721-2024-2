let w = 0;
let h = 0;
let s = 0;
let visitedPercent = 0;
let cost = 1;

let isSPressed = false;
let isGPressed = false;
let isCPressed = false;

let init = null;
let end = null;

let path = [];
let visited = [];
let maps = [];
let world = [];

// Connect to WebSocket server
const socket = io('http://localhost:5001');

// Event listener for when the connection is established
socket.on('connect', function () {
    console.log('Connected to WebSocket server');
});

// Event listener for incoming messages
socket.on('message_from_server', function (message) {
    console.log('Message from server:', message);
    if (message['map'] != null) {
        if(message['type'] != 'end') {
            world = message['map'];
            path = message['path']; 

            socket.emit('message_from_client',  'next');
        }
    }
});

function startSearch() {
    if (!validateMap()) {
        return;
    }
    
    let map = worldToMap();

    let populationSize = document.getElementById('populationSize').value;
    let numberGenerations = document.getElementById('numberGenerations').value;
    let mutationRate = document.getElementById('mutationRate').value;

    // Construct the URL with parameters
    var url = `http://localhost:5001/start_search?map=${encodeURIComponent(map)}&pop=${populationSize}&gen=${numberGenerations}&mut=${mutationRate}&vis=${visited}`;

    // Make a GET request to the server
    fetch(url)
    .then(response => response.json())
    .then(data => {
        console.log(data);
        socket.emit('message_from_client',  'next');
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function startMap() {
    init = null;
    end = null;
    path = [];
    visited = []

    let mapW = Math.floor(w/s);
    let mapH = Math.floor(h/s);

    world = new Array(mapH);
    for (let i = 0; i < mapH; i++) {
        world[i] = new Array(mapW);
        for (let j = 0; j < mapW; j++) {
            world[i][j] = '1';
        }
    }     
}

function setup() {
    w = 840;
    h = 400;
    s = 35;

    // Genetic algorithm parameters
    v = 50;
    popSize = 100;
    nGen = 100;
    mRate = 1;

    // Create canvas
    let mapCanvas = createCanvas(w, h);
    mapCanvas.parent("mapCanvas");

    // Config inputs
    document.getElementById('scaleMap').value = s;
    
    document.getElementById('populationSize').value = popSize;
    document.getElementById('numberGenerations').value = nGen;
    document.getElementById('mutationRate').value = mRate;
    
    // Init world
    startMap();    
}

function updateMapSize() {
    s = document.getElementById('scaleMap').value;
    startMap();
}

function updateNumberGenerations() {
    nGen = document.getElementById('numberGenerations').value;
}

function updatePopulationSize() {
    popSize = document.getElementById('populationSize').value;
}

function updateMutationRate() {
    mRate = document.getElementById('mutationRate').value;
}

function draw() {
    clear();
    
    background(255);
    stroke(240);

    if(world[0] == null){
        return;
    }

    let mapW = Math.floor(w/s);
    let mapH = Math.floor(h/s);
    
    for(let i = 0; i < mapH; i++) {
        for(let j = 0; j < mapW; j++) {
            if(world[i][j] == 'X') {
                fill(80); 
            }
            else if(world[i][j] == '1') {
                fill(255);
            }

            rect(j*s, i*s, s, s);
        }
    }

    // draw visited
    if(visited.length > 0) {
        for(let n of visited) {
            fill(196, 166, 60, 80);
            rect(n[0]*s, n[1]*s, s, s);
        }
    }

    // draw path
    if(path.length > 0) {
        for(let n of path) {
            fill(200);
            rect(n[0]*s, n[1]*s, s, s);
        }
    }

    // draw init
    if(init != null) {
        fill(130, 151, 199);
        rect(init.x*s, init.y*s, s, s);
    }

    // draw end
    if(end != null) {
        fill(100, 252, 80);
        rect(end.x*s, end.y*s, s, s);
    }
    
}

function mapToWorld(map) {
    let lines = map.split('\n');
    let mapH = lines.length;
    let mapW = lines[0].length;

    let world = new Array(mapH);
    for (let i = 0; i < mapH; i++) {
        world[i] = new Array(mapW);
        for (let j = 0; j < mapW; j++) {
            world[i][j] = lines[i][j];
        }
    }

    return world;
}

function worldToMap() {
    let mapW = Math.floor(w/s);
    let mapH = Math.floor(h/s);

    let map = '';
    for(let i = 0; i < mapH; i++) {
        for(let j = 0; j < mapW; j++) {
            map += world[i][j];
        }
        map += '\n';
    }

    return map;
}

function validateMap() {
    if(init == null) {
        alert('Por favor insira um estado inicial. Segura S e clique no mapa para inserir um estado inicial.');
        return false;
    }

    if(end == null) {
        alert('Por favor insira um estado final. Segura G e clique no mapa para inserir um estado final.');
        return false;
    }

    return true;
}

// =================
// Input Functions
// =================

function saveMap() {
    let mapName = document.getElementById('nameMap').value;

    if(!validateMap()) {
        return false;
    }

    if(mapName == '') {
        alert('Por favor insira um nome para o mapa');
        return false;
    }

    // Construct the URL with parameters
    let map = worldToMap();
    var url = `http://localhost:5001/save_map?map_name=${encodeURIComponent(mapName)}&map=${encodeURIComponent(map)}`;

    // Make a GET request to the server
    fetch(url)
    .then(response => response.json())
    .then(data => {
        // Alert the response from the server
        alert("Mapa salvo com sucesso!");
        getMaps();
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function mousePressed() {
    let x = int(mouseX/s);
    let y = int(mouseY/s);

    if (mouseButton === LEFT) {
        if(x < 0 || x >= world[0].length || y < 0 || y >= world.length) {
            return;
        }

        if (isSPressed) {
            world[y][x] = 'S';
            if(init != null) {
                world[init.y][init.x] = '1';
            }
            init = createVector(x, y);
            path = [];
            visited = [];
        }
        else if (isGPressed) {
            world[y][x] = 'G';
            if(end != null) {
                world[end.y][end.x] = '1';
            }
            end = createVector(x, y);
            path = [];
            visited = [];
        }
    }
}

function keyPressed() {
    // Check if key s is pressed
    if (keyCode === 83) {
        isSPressed = true;
    }

    // Check if g is pressed
    if (keyCode === 71) {
        isGPressed = true;
    }
}

function keyReleased() {
    // Check if key s is pressed
    if (keyCode === 83) {
        isSPressed = false;
    }

    // Check if g is pressed
    if (keyCode === 71) {
        isGPressed = false;
    }
}