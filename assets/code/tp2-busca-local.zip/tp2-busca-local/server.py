import os
from flask import Flask, render_template, request, jsonify
from genetic import GeneticAlgorithm
from search import parse_level
from flask_socketio import SocketIO, emit

app = Flask(__name__)
socketio = SocketIO(app, async_mode='eventlet')

# Directory containing the text files
maps_directory = 'maps'
ga = None

@app.route('/')
def index():
    return render_template('index.html')
    
@app.route('/start_search', methods=['GET'])
def start_search():    
    # Get width and height from query parameters
    population_size = int(request.args.get('pop'))
    n_generations = int(request.args.get('gen'))
    mut_rate = float(request.args.get('mut'))/100
    
    map = request.args.get('map')
    map_rows = map.split('\n')

    height = len(map_rows) - 1
    width = len(map_rows[0])

    # Load the level from the file
    level = parse_level(map_rows)

    # Retrieve the source and destination coordinates from the level.
    start = level['start']
    goal = level['goal']

    # Plan the path
    global ga
    ga = GeneticAlgorithm(population_size, n_generations, mut_rate, width, height, start, goal)

    # Perform search algorithm logic here with map_name and algorithm_name
    # For demonstration purposes, just returning a simple response
    response = jsonify({'result': 'success'})
    response.headers.add("Access-Control-Allow-Origin", "*")

    return response

@app.route('/save_map', methods=['GET'])
def save_map():
    try:
        # Get filename and content from query parameters
        map_name = request.args.get('map_name')
        map_data = request.args.get('map')

        # Write the content to a file
        with open(f'{maps_directory}/{map_name}.txt', 'w') as file:
            file.write(map_data)

        response = jsonify({'result': 'success'})
        response.headers.add("Access-Control-Allow-Origin", "*")

        return response

    except Exception as e:
        return jsonify({'result': 'error', 'error_details': str(e)}), 500
    
@socketio.on('message_from_client')
def handle_message(data):
    if data == 'next':
        map, path = ga.evolve()

        if map == None:
            emit('message_from_server', {"type": "end", "i": ga.current_generation})
            return
        
        emit('message_from_server', {"type": "gen", "i": ga.current_generation, "map": map, 'path': path})

if __name__ == '__main__':
    # Use the SSL context for HTTPS
    socketio.run(app, host="0.0.0.0", port="5001", debug=True)
