import termcolor
from logic import *

mustard = Symbol("Mustard")
plum = Symbol("Plum")
scarlet = Symbol("Scarlet")
characters = [mustard, plum, scarlet]

festa = Symbol("festa")
cozinha = Symbol("cozinha")
biblioteca = Symbol("biblioteca")
salas = [festa, cozinha, biblioteca]

faca = Symbol("faca")
revolver = Symbol("revolver")
chave = Symbol("chave")
weapons = [faca, revolver, chave]

simbolos = characters + salas + weapons

def check_knowledge(bc):
    for s in simbolos:
        if model_check(bc, s):
            termcolor.cprint(f"{s}: Sim", "green")
        elif model_check(bc, Not(s)):
            termcolor.cprint(f"{s}: Não", "red")
        else:
            termcolor.cprint(f"{s}: Talvez", "yellow")

# Criação da base de conhecimento

# 1. Pelas regras do jogo:
bc = And(
    Or(mustard, plum, scarlet),
    Or(festa, cozinha, biblioteca),
    Or(faca, revolver, chave)
)

# check_knowledge(bc)

# 2. Após receber as cartas:
bc.add(And(
    Not(mustard),
    Not(cozinha),
    Not(revolver)
))

# check_knowledge(bc)

# 3. Sugestão falsa que alguém fez: Scarlet usando uma chave na biblioteca
bc.add(Or(
    Not(scarlet),
    Not(biblioteca),
    Not(chave),
))

# check_knowledge(bc)

# 4. Eu fiz uma sugestão falsa: Plum usando uma faca no salao.
# Como eu fiz a sugestão falsa, alguém vai provar mostrando
# uma cara para mim. 
bc.add(Not(plum))
bc.add(Not(festa))

# chave é falso pelo item 3.
# faca é verdadeira pelo item 1.

check_knowledge(bc)

