from logic import *

# Definir os símbolos do problema
p = Symbol("greve")
q = Symbol("aula")
r = Symbol("casa")

# Definir as sentenças
sentenca1 = Implication(Not(p), q)
sentenca2 = Or(And(q, Not(r)), And(Not(q), r))
sentenca3 = r

# Definir base de conhecimento
base = And(sentenca1, sentenca2, sentenca3)

print("Houve greve?", model_check(base, p))